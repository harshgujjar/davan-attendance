// ══════════════════════════════════════════════════════════════
//  Davan WA Bulk Sender — background.js
//  Queue manager + tab orchestration
//  Works with Manifest V3 (Chrome/Opera) and V2 (Firefox)
// ══════════════════════════════════════════════════════════════

let state = {
  queue:     [],       // [{ name, phone, message }, ...]
  index:     0,        // current position
  total:     0,
  delay:     30,       // seconds between messages
  mainTabId: null,     // tab id of the Davan app
  waTabId:   null,     // current WhatsApp Web tab
  paused:    false,
  running:   false,
  timer:     null,     // setInterval handle
  countdown: 0,
};

// ── Listen for messages from main app (via content bridge) or popup ──
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {

  // ── START ──
  if (msg.type === 'DAVAN_START_BULK') {
    state.queue     = msg.queue || [];
    state.delay     = msg.delay || 30;
    state.index     = 0;
    state.total     = state.queue.length;
    state.mainTabId = msg.mainTabId || sender.tab?.id || null;
    state.paused    = false;
    state.running   = true;
    state.waTabId   = null;
    saveState();
    processNext();
    sendResponse({ ok: true });
    return true;
  }

  // ── PING — main app checks if extension is installed ──
  if (msg.type === 'DAVAN_PING') {
    // Also record the main tab id here so notifyMain works even before START
    if (sender.tab?.id) state.mainTabId = sender.tab.id;
    sendResponse({ ok: true, version: '1.0' });
    return true;
  }

  // ── SENT — content script reports WhatsApp send succeeded ──
  if (msg.type === 'WA_SENT') {
    handleSent(sender.tab?.id);
    sendResponse({ ok: true });
    return true;
  }

  // ── SEND ERROR — content script couldn't find Send button ──
  if (msg.type === 'WA_ERROR') {
    console.warn('[BulkSender] Send error on tab', sender.tab?.id, msg.reason);
    handleSent(sender.tab?.id, true); // skip and move on
    sendResponse({ ok: true });
    return true;
  }

  // ── PAUSE ──
  if (msg.type === 'DAVAN_PAUSE') {
    state.paused = true;
    clearInterval(state.timer);
    state.timer = null;
    saveState();
    sendResponse({ ok: true });
    return true;
  }

  // ── RESUME ──
  if (msg.type === 'DAVAN_RESUME') {
    state.paused = false;
    saveState();
    processNext();
    sendResponse({ ok: true });
    return true;
  }

  // ── STOP ──
  if (msg.type === 'DAVAN_STOP') {
    stopAll();
    sendResponse({ ok: true });
    return true;
  }

  // ── STATUS — popup asks for current state ──
  if (msg.type === 'DAVAN_STATUS') {
    sendResponse({
      running:   state.running,
      paused:    state.paused,
      index:     state.index,
      total:     state.total,
      countdown: state.countdown,
      current:   state.queue[state.index] || null,
    });
    return true;
  }
});

// ── Also listen for postMessage relay from content bridge in main app tab ──
chrome.runtime.onMessageExternal?.addListener?.((msg, sender, sendResponse) => {
  // External messages from web pages (if externally_connectable set)
  // Relay to internal handler
  chrome.runtime.sendMessage(msg, sendResponse);
  return true;
});

// ── Process next student in queue ──
function processNext() {
  if (!state.running || state.paused) return;
  if (state.index >= state.total) {
    finishAll();
    return;
  }

  const student = state.queue[state.index];
  if (!student) { state.index++; processNext(); return; }

  // Validate phone
  const phone = cleanPhone(student.phone);
  if (!phone) {
    console.warn('[BulkSender] Skipping — no valid phone:', student.name);
    notifyMain({ type: 'PROGRESS', sent: state.index, total: state.total, skipped: true, name: student.name });
    state.index++;
    processNext();
    return;
  }

  const url = buildWAUrl(phone, student.message);
  notifyMain({ type: 'OPENING', sent: state.index, total: state.total, name: student.name, phone });

  // Open WhatsApp Web tab
  chrome.tabs.create({ url, active: true }, (tab) => {
    state.waTabId = tab.id;
    saveState();
  });
}

// ── Called when WA_SENT or WA_ERROR received from content script ──
function handleSent(tabId, isError = false) {
  // Close the WhatsApp tab
  if (state.waTabId) {
    chrome.tabs.remove(state.waTabId, () => {});
    state.waTabId = null;
  }

  const student = state.queue[state.index];
  notifyMain({
    type:    isError ? 'SKIPPED' : 'SENT',
    sent:    state.index + 1,
    total:   state.total,
    name:    student?.name || '',
    phone:   student?.phone || '',
  });

  state.index++;
  saveState();

  if (state.index >= state.total) {
    finishAll();
    return;
  }

  // Start countdown to next
  state.countdown = state.delay;
  clearInterval(state.timer);
  state.timer = setInterval(() => {
    state.countdown--;
    notifyMain({ type: 'COUNTDOWN', countdown: state.countdown, sent: state.index, total: state.total });
    if (state.countdown <= 0) {
      clearInterval(state.timer);
      state.timer = null;
      if (!state.paused) processNext();
    }
  }, 1000);
}

function finishAll() {
  state.running = false;
  clearInterval(state.timer);
  state.timer = null;
  notifyMain({ type: 'DONE', sent: state.index, total: state.total });
  saveState();
}

function stopAll() {
  state.running = false;
  state.paused  = false;
  clearInterval(state.timer);
  state.timer = null;
  if (state.waTabId) {
    chrome.tabs.remove(state.waTabId, () => {});
    state.waTabId = null;
  }
  notifyMain({ type: 'STOPPED', sent: state.index, total: state.total });
  saveState();
}

// ── Send progress message back to main app tab ──
function notifyMain(data) {
  if (!state.mainTabId) return;
  chrome.tabs.sendMessage(state.mainTabId, { ...data, _davan: true }, () => {
    // Ignore errors if tab closed
    if (chrome.runtime.lastError) {}
  });
}

// ── Helpers ──
function cleanPhone(raw) {
  if (!raw) return '';
  const digits = String(raw).replace(/\D/g, '');
  if (digits.length === 10) return '91' + digits;
  if (digits.length === 12 && digits.startsWith('91')) return digits;
  if (digits.length === 11 && digits.startsWith('0')) return '91' + digits.slice(1);
  if (digits.length >= 10) return digits;
  return '';
}

function buildWAUrl(phone, message) {
  return 'https://web.whatsapp.com/send?phone=' + phone +
    '&text=' + encodeURIComponent(message || '') +
    '&app_absent=0';
}

function saveState() {
  chrome.storage.session?.set?.({ bulkState: state });
}

// ── On startup: restore state if extension reloaded mid-send ──
chrome.storage.session?.get?.(['bulkState'], (result) => {
  if (result?.bulkState?.running) {
    state = result.bulkState;
    // Don't auto-resume — let user click Resume in popup
    state.running = false;
    state.paused  = true;
  }
});
