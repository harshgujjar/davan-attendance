// ══════════════════════════════════════════════════════════════
//  Davan WA Bulk Sender — content_whatsapp.js
//  Injected into https://web.whatsapp.com/*
//  Waits for Send button, clicks it, signals background.js
// ══════════════════════════════════════════════════════════════

(function () {
  'use strict';

  // Only run if this tab was opened by the bulk sender
  // (wa.me links opened by the extension will have our phone+text params)
  const url = new URL(location.href);
  if (!url.searchParams.has('phone') && !url.searchParams.has('text')) return;

  const MAX_WAIT_MS  = 20000;  // give up after 20s
  const RETRY_MS     = 500;    // check every 500ms
  const POST_SEND_MS = 2000;   // wait 2s after click to confirm

  // WhatsApp Web send button selectors — ordered by reliability
  const SEND_SELECTORS = [
    'button[data-testid="compose-btn-send"]',
    '[data-testid="send"]',
    'span[data-icon="send"]',
    'button[aria-label="Send"]',
    'div[aria-label="Send"]',
    'footer button[type="submit"]',
    '[data-tab="11"]',
  ];

  let sent      = false;
  let elapsed   = 0;
  let intervalId = null;

  function findSendBtn() {
    for (const sel of SEND_SELECTORS) {
      try {
        const el = document.querySelector(sel);
        if (el && isVisible(el)) return el;
      } catch (e) {}
    }
    return null;
  }

  function isVisible(el) {
    if (!el) return false;
    const rect = el.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0 &&
           window.getComputedStyle(el).visibility !== 'hidden' &&
           window.getComputedStyle(el).display !== 'none';
  }

  function trySend() {
    if (sent) return;
    const btn = findSendBtn();
    if (!btn) return;

    // Extra check: make sure the input has content (WA pre-fills from URL)
    const input = document.querySelector('[data-testid="conversation-compose-box-input"]')
                || document.querySelector('div[contenteditable="true"]');
    const hasText = input && (input.textContent || input.innerText || '').trim().length > 0;

    if (!hasText) return; // message not loaded yet

    // Click!
    btn.click();
    sent = true;
    clearInterval(intervalId);

    // Wait a moment then confirm to background
    setTimeout(() => {
      try {
        chrome.runtime.sendMessage({ type: 'WA_SENT' });
      } catch (e) {
        console.warn('[DavanExt] Could not signal background:', e);
      }
    }, POST_SEND_MS);
  }

  function giveUp() {
    clearInterval(intervalId);
    if (!sent) {
      try {
        chrome.runtime.sendMessage({ type: 'WA_ERROR', reason: 'Send button not found after ' + MAX_WAIT_MS + 'ms' });
      } catch (e) {}
    }
  }

  // Start polling once DOM is ready
  function startPolling() {
    intervalId = setInterval(() => {
      elapsed += RETRY_MS;
      trySend();
      if (elapsed >= MAX_WAIT_MS) giveUp();
    }, RETRY_MS);

    // Also observe DOM changes (WA is a SPA — content loads dynamically)
    const observer = new MutationObserver(() => {
      if (!sent) trySend();
    });
    observer.observe(document.body, { childList: true, subtree: true });

    // Disconnect observer after max wait
    setTimeout(() => {
      observer.disconnect();
      if (!sent) giveUp();
    }, MAX_WAIT_MS + 1000);
  }

  // Wait for body to be ready
  if (document.body) {
    startPolling();
  } else {
    document.addEventListener('DOMContentLoaded', startPolling);
  }

  // Also listen for messages from background (e.g. manual retry trigger)
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === 'WA_RETRY') {
      sent = false;
      elapsed = 0;
      clearInterval(intervalId);
      startPolling();
    }
  });

})();
