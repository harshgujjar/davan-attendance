// ══════════════════════════════════════════════════════════════
//  Davan WA Bulk Sender — content_bridge.js
//  Injected into the Davan app tab (file:// or any origin)
//  Bridges postMessage (from page JS) ↔ chrome.runtime messages
// ══════════════════════════════════════════════════════════════

(function () {
  'use strict';

  // ── Page → Extension ──
  window.addEventListener('message', (e) => {
    if (!e.data) return;
    // Accept both type and _type so page can use either field name
    const msgType = e.data.type || e.data._type || '';
    const RELAY_TYPES = ['DAVAN_PING', 'DAVAN_START_BULK', 'DAVAN_PAUSE', 'DAVAN_RESUME', 'DAVAN_STOP', 'DAVAN_STATUS'];
    if (!RELAY_TYPES.includes(msgType)) return;

    // IMPORTANT: chrome.tabs.getCurrent() does NOT work in content scripts —
    // it is only available in extension pages (popup, options page).
    // Calling it here causes the callback to never fire, silently dropping
    // the message. We send directly; background gets sender.tab.id automatically.
    const msg = { ...e.data, type: msgType };

    chrome.runtime.sendMessage(msg, (response) => {
      if (chrome.runtime.lastError) {
        // Extension context not ready — ignore
        return;
      }
      // Relay response back to page with both type and _type for compatibility
      window.postMessage({
        ...(response || {}),
        type:   msgType + '_RESPONSE',
        _type:  msgType + '_RESPONSE',
        _davan: true,
      }, '*');
    });
  });

  // ── Extension → Page (progress / countdown messages from background) ──
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg && msg._davan) {
      window.postMessage(msg, '*');
    }
  });

  // Signal to page that extension is ready on inject
  // Also fires type so page ntCheckExtension can catch it if listening early
  window.postMessage({
    _davan: true,
    type:   'DAVAN_EXTENSION_READY',
    _type:  'DAVAN_EXTENSION_READY',
    version: '1.0',
  }, '*');

})();
