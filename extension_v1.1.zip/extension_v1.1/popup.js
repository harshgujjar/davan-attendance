// ══════════════════════════════════════════════════════════════
//  Davan WA Bulk Sender — popup.js
// ══════════════════════════════════════════════════════════════

const content = document.getElementById('content');

function pct(sent, total) {
  return total > 0 ? Math.round((sent / total) * 100) : 0;
}

function render(s) {
  if (!s || !s.running && !s.paused && s.index === 0 && s.total === 0) {
    content.innerHTML = `
      <div class="idle-msg">
        <span>💤</span>
        No bulk send active.<br>
        Open the Davan app and<br>use <strong>Bulk Send</strong> in Notify.
      </div>`;
    return;
  }

  const statusClass = s.paused ? 'status-paused' : (s.running ? 'status-active' : 'status-done');
  const statusText  = s.paused ? '⏸ Paused' : (s.running ? '▶ Sending…' : '✅ Complete');
  const p = pct(s.index, s.total);
  const cur = s.current;

  content.innerHTML = `
    <div class="status-box">
      <div class="status-label">Status</div>
      <div class="status-text ${statusClass}">${statusText}</div>

      <div class="progress-wrap">
        <div class="progress-bar-bg">
          <div class="progress-bar-fill" style="width:${p}%"></div>
        </div>
        <div class="progress-text">
          <span>${s.index} of ${s.total} sent</span>
          <span>${p}%</span>
        </div>
      </div>

      ${cur ? `
      <div class="current-student">
        <div class="current-name">▸ ${cur.name}</div>
        <div class="current-phone">${cur.phone}</div>
      </div>` : ''}

      ${s.running && !s.paused && s.countdown > 0 ? `
      <div class="countdown">${s.countdown}s</div>
      <div class="countdown-label">next message opens in…</div>` : ''}
    </div>

    <div class="btn-row">
      ${s.paused
        ? `<button class="btn-resume" id="btn-resume">▶ Resume</button>`
        : `<button class="btn-pause"  id="btn-pause">⏸ Pause</button>`}
      <button class="btn-stop" id="btn-stop">■ Stop</button>
    </div>`;

  document.getElementById('btn-pause')?.addEventListener('click', () => {
    chrome.runtime.sendMessage({ type: 'DAVAN_PAUSE' }, refresh);
  });
  document.getElementById('btn-resume')?.addEventListener('click', () => {
    chrome.runtime.sendMessage({ type: 'DAVAN_RESUME' }, refresh);
  });
  document.getElementById('btn-stop')?.addEventListener('click', () => {
    chrome.runtime.sendMessage({ type: 'DAVAN_STOP' }, refresh);
  });
}

function refresh() {
  chrome.runtime.sendMessage({ type: 'DAVAN_STATUS' }, render);
}

// Initial load
refresh();

// Poll every second while popup is open
setInterval(refresh, 1000);
